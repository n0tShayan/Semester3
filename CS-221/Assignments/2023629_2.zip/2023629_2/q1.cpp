#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int value) : data(value), next(nullptr) {}
};

class LinkedList {
public:
    Node* head;

    LinkedList() : head(nullptr) {}

    void append(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    int detectAndRemoveLoop() {
        Node* slow = head;
        Node* fast = head;
        int pos = 1;

        while (fast != nullptr && fast->next != nullptr) {
            slow = slow->next;
            fast = fast->next->next;
            if (slow == fast) {
                cout << "Loop detected" << endl;
                return removeLoop(slow);
            }
        }
        cout << "No loop detected" << endl;
        return -1;
    }

    int removeLoop(Node* loopNode) {
        Node* ptr1 = head;
        Node* ptr2 = loopNode;
        int pos = 1;

        while (ptr1 != ptr2) {
            ptr1 = ptr1->next;
            ptr2 = ptr2->next;
            pos++;
        }

        cout << "Loop starts at node #" << pos << " with value " << ptr1->data << endl;

        Node* startNode = ptr1;
        Node* temp = startNode;
        while (temp->next != startNode) {
            temp = temp->next;
        }
        temp->next = nullptr;

        cout << "Loop removed from Node #" << pos + 2 << " -> Node #" << pos << endl;
        return startNode->data;
    }

    void printList() {
        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    LinkedList list;
    list.append(3);
    list.append(5);
    list.append(7);
    list.append(8);
    list.append(10);

    list.head->next->next->next->next->next = list.head->next->next;

    int loopStartValue = list.detectAndRemoveLoop();

    if (loopStartValue != -1) {
        cout << "Loop starts at node with value: " << loopStartValue << endl;
    }

    cout << "List after removing loop: ";
    list.printList();

    return 0;
}
