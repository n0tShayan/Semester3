#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
    Node(int value) : data(value), next(nullptr), prev(nullptr) {}
};

class DoublyLinkedList {
public:
    Node* head;
    Node* tail;

    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(int value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    void swapNodes(Node* a, Node* b) {
        if (!a || !b || a == b) return;

        if (a->next == b) {
            if (a->prev) a->prev->next = b;
            if (b->next) b->next->prev = a;
            b->prev = a->prev;
            a->next = b->next;
            a->prev = b;
            b->next = a;
        } else if (b->next == a) {
            if (b->prev) b->prev->next = a;
            if (a->next) a->next->prev = b;
            a->prev = b->prev;
            b->next = a->next;
            b->prev = a;
            a->next = b;
        } else {
            Node* aPrev = a->prev;
            Node* aNext = a->next;
            Node* bPrev = b->prev;
            Node* bNext = b->next;

            if (aPrev) aPrev->next = b;
            if (aNext) aNext->prev = b;
            if (bPrev) bPrev->next = a;
            if (bNext) bNext->prev = a;

            a->prev = bPrev;
            a->next = bNext;
            b->prev = aPrev;
            b->next = aNext;
        }

        if (head == a) head = b;
        else if (head == b) head = a;
        if (tail == a) tail = b;
        else if (tail == b) tail = a;
    }

    void display() const {
        Node* current = head;
        while (current) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

int main() {
    DoublyLinkedList list;
    list.append(3);
    list.append(1);
    list.append(8);
    list.append(5);
    list.append(4);
    list.append(2);
    list.append(9);
    list.append(6);
    list.append(7);
    list.append(0);

    Node* first = list.head;
    Node* second = list.head->next->next;  // Node with value 8

    cout << "Before    Swapping:\n";
    list.display();
    list.swapNodes(first, second);
    cout << "After Swapping:\n";
    list.display();

    return 0;
}
