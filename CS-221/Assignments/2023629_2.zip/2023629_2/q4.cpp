#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
    
    Node(int val) : data(val), next(nullptr), prev(nullptr) {}
};

void moveHeadToPosition(Node*& head, int position) {
    if (!head || position <= 0) return;  

    Node* current = head;
    int count = 1;

    while (current && count < position) {
        current = current->next;
        count++;
    }

    if (current) {

        if (current->prev) current->prev->next = current->next;
        if (current->next) current->next->prev = current->prev;

        current->prev = nullptr;
        current->next = head;

        if (head) head->prev = current;

        head = current;
    }
}

void printList(Node* head) {
    Node* temp = head;
    while (temp) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}


Node* createList() {
    Node* head = new Node(1);
    head->next = new Node(2);
    head->next->prev = head;
    head->next->next = new Node(3);
    head->next->next->prev = head->next;
    head->next->next->next = new Node(4);
    head->next->next->next->prev = head->next->next;
    return head;
}

int main() {
    Node* head = createList();
    cout << "Original List: ";
    printList(head);

    int position = 3;
    moveHeadToPosition(head, position);

    cout << "List after moving head to position " << position << ": ";
    printList(head);

    return 0;
}