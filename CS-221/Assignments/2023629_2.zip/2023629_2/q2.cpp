#include <iostream>
#include <string>
using namespace std;

class Person {
public:
    string name;
    string address;
    string phone;

    Person(string name = "", string address = "", string phone = "") 
        : name(name), address(address), phone(phone) {}
};

struct Node {
    Person person;
    Node* next;

    Node(Person p) : person(p), next(nullptr) {}
};

class AddressBook {
private:
    Node* head;

public:
    AddressBook() : head(nullptr) {}

    void addEntry(const Person& p) {
        Node* newNode = new Node(p);

        if (!head || head->person.name > p.name) {
            newNode->next = head;
            head = newNode;
        } else {
            Node* current = head;
            while (current->next && current->next->person.name < p.name) {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }

        cout << "Entry added successfully." << endl;
    }

    void displayEntries() const {
        Node* current = head;
        while (current) {
            cout << "Name: " << current->person.name
                 << ", Address: " << current->person.address
                 << ", Phone: " << current->person.phone << endl;
            current = current->next;
        }
    }

    Person* find(const string& name) const {
        Node* current = head;
        while (current) {
            if (current->person.name == name) {
                cout << "Found: " << current->person.name << endl;
                return &(current->person);
            }
            current = current->next;
        }
        cout << "Person not found." << endl;
        return nullptr;
    }
};

int main() {
    AddressBook addressBook;
    int choice;

    do {
        cout << "1. Add Entry\n2. Display Entries\n3. Find Entry\n4. Exit\nChoose an option: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string name, address, phone;
            cout << "Enter Name: ";
            getline(cin, name);
            cout << "Enter Address: ";
            getline(cin, address);
            cout << "Enter Phone: ";
            getline(cin, phone);
            Person p(name, address, phone);
            addressBook.addEntry(p);
        } else if (choice == 2) {
            addressBook.displayEntries();
        } else if (choice == 3) {
            string name;
            cout << "Enter Name to Find: ";
            getline(cin, name);
            addressBook.find(name);
        } else if (choice != 4) {
            cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
