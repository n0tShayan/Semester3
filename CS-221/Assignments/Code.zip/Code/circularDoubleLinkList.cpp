#include <iostream>
using namespace std;

// Node structure for circular doubly linked list
struct Node {
    int data;       // Data
    Node* next;     // Pointer to the next node
    Node* prev;     // Pointer to the previous node
};

// Circular Doubly Linked List class
class CircularDoublyLinkedList {
private:
    Node* head;     // Pointer to the first node
    Node* tail;     // Pointer to the last node

public:
    CircularDoublyLinkedList() {
        head = NULL;  // Initialize head to null
        tail = NULL;
    }

    // Add a node at the end of the list
    void insertEnd(int value) {
        Node* newNode = new Node;  // Create a new node using struct
        newNode->data = value;
        newNode->next = NULL;
        newNode->prev = NULL;

        if (head == NULL) {  // If the list is empty
            head = newNode;     // Make the new node the head
            head->next = head;  // Point it to itself (circular)
            head->prev = head;  // Point it to itself (circular)
        } else {
            tail = head->prev;  // Get the last node (tail)
            tail->next = newNode;     // Make last node's next point to the new node
            newNode->prev = tail;     // Make new node's prev point to the last node
            newNode->next = head;     // Make new node's next point to the head
            head->prev = newNode;     // Update head's prev pointer to the new node
        }
    }

    // Display the circular doubly linked list forward
    void displayForward() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }

        Node* current = head;
        do {
            cout << current->data << " -> ";
            current = current->next;
        } while (current != head);  // Traverse until we come back to the head
        cout << "(back to head)" << endl;
    }

    // Display the circular doubly linked list backward
    void displayBackward() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }

        tail = head->prev;  // Get the last node (tail)
        Node* current = tail;
        do {
            cout << current->data << " -> ";
            current = current->prev;
        } while (current != tail);  // Traverse until we come back to the tail
        cout << "(back to tail)" << endl;
    }
};

int main() {
    CircularDoublyLinkedList list;
    list.insertEnd(10);
    list.insertEnd(20);
    list.insertEnd(30);
    list.insertEnd(40);

    cout << "Display forward: ";
    list.displayForward();   // Output: 10 -> 20 -> 30 -> 40 -> (back to head)

    cout << "Display backward: ";
    list.displayBackward();  // Output: 40 -> 30 -> 20 -> 10 -> (back to tail)

    return 0;
}

