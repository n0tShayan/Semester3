#include <iostream>
using namespace std;

// Node structure for circular singly linked list
struct Node {
    int data;       // Data
    Node* next;     // Pointer to the next node
};

// Circular Singly Linked List class
class CircularSinglyLinkedList {
private:
    Node* head;     // Pointer to the first node

public:
    CircularSinglyLinkedList() {
        head = NULL;  // Initialize head to null
    }

    // Add a node at the end of the list
    void insertEnd(int value) {
        Node* newNode = new Node;  // Create a new node
        newNode->data = value;
        newNode->next = NULL;

        if (head == NULL) {  // If the list is empty
            head = newNode;     // Make the new node the head
            head->next = head;  // Point it to itself (circular)
        } else {
            Node* temp = head;
            while (temp->next != head) {  // Traverse to the last node
                temp = temp->next;
            }
            temp->next = newNode;  // Last node's next points to new node
            newNode->next = head;  // New node's next points to head
        }
    }

    // Add a node at the start of the list
    void insertStart(int value) {
        Node* newNode = new Node;  // Create a new node
        newNode->data = value;
        newNode->next = NULL;

        if (head == NULL) {  // If the list is empty
            head = newNode;     // Make the new node the head
            head->next = head;  // Point it to itself (circular)
        } else {
            Node* temp = head;
            while (temp->next != head) {  // Traverse to the last node
                temp = temp->next;
            }
            newNode->next = head;  // New node's next points to the current head
            temp->next = newNode;  // Last node's next points to the new node
            head = newNode;        // Update head to point to the new node
        }
    }

    // Add a node at a specific position (1-based index)
    void insertAtPosition(int value, int position) {
        Node* newNode = new Node;  // Create a new node
        newNode->data = value;
        newNode->next = NULL;

        if (position < 1) {
            cout << "Invalid position!" << endl;
            return;
        }

        if (position == 1) {  // Insert at start if position is 1
            insertStart(value);
            return;
        }

        Node* temp = head;
        int count = 1;

        while (count < position - 1 && temp->next != head) {  // Traverse to the node just before the target position
            temp = temp->next;
            count++;
        }

        if (count < position - 1) {
            cout << "Position out of range!" << endl;
            return;
        }

        newNode->next = temp->next;  // New node's next points to the next node
        temp->next = newNode;        // The current node's next points to the new node
    }

    // Display the circular singly linked list
    void display() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }

        Node* current = head;
        do {
            cout << current->data << " -> ";
            current = current->next;
        } while (current != head);  // Traverse until we come back to the head
        cout << "(back to head)" << endl;
    }
};

int main() {
    CircularSinglyLinkedList list;
    
    list.insertEnd(20);
    list.insertEnd(30);
    list.insertEnd(40);

    cout << "List after inserting at end: " << endl;
    list.display();   // Output: 20 -> 30 -> 40 -> (back to head)

    list.insertStart(10);    // Insert at the start
    
    cout << "List after inserting at start: " << endl;
    list.display();   // Output: 10 -> 20 -> 30 -> 40 -> (back to head)

    list.insertAtPosition(25, 3);    // Insert at position 3
    
    cout << "List after inserting at position 3: " << endl;
    list.display();   // Output: 10 -> 20 -> 25 -> 30 -> 40 -> (back to head)

    list.insertAtPosition(5, 1);     // Insert at position 1 (start)
    
    cout << "List after inserting at position 1: " << endl;
    list.display();   // Output: 5 -> 10 -> 20 -> 25 -> 30 -> 40 -> (back to head)

    return 0;
}

