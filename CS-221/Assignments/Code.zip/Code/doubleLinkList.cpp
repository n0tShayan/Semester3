#include <iostream>
using namespace std;

// Node structure for doubly linked list
struct Node {
    int data;       // Data
    Node* next;     // Pointer to the next node
    Node* prev;     // Pointer to the previous node
};

// Doubly Linked List class
class DoublyLinkedList {
private:
    Node* head;     // Pointer to the first node
    Node* tail;     // Pointer to the last node

public:
    DoublyLinkedList() {
        head = NULL;
        tail = NULL;
    }

    // Add a node at the front
    void insertFront(int value) {
        Node* newNode = new Node;    // Create new node
        newNode->data = value;
        newNode->next = head;        // New node points to the old head
        newNode->prev = NULL;     // New node's previous is null

        if (head != NULL) {
            head->prev = newNode;    // Update old head's previous pointer
        } else {
            tail = newNode;          // If list was empty, newNode is also the tail
        }

        head = newNode;              // Update head to point to new node
    }

    // Add a node at the end
    void insertEnd(int value) {
        Node* newNode = new Node;    // Create new node
        newNode->data = value;
        newNode->next = NULL;     // New node's next is null
        newNode->prev = tail;        // New node's previous points to the old tail

        if (tail != NULL) {
            tail->next = newNode;    // Update old tail's next pointer
        } else {
            head = newNode;          // If list was empty, newNode is also the head
        }

        tail = newNode;              // Update tail to point to new node
    }

    // Display list from head to tail
    void displayForward() {
        Node* current = head;
        while (current != NULL) {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "NULL" << endl;
    }

    // Display list from tail to head
    void displayBackward() {
        Node* current = tail;
        while (current != NULL) {
            cout << current->data << " -> ";
            current = current->prev;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    DoublyLinkedList list;
    list.insertFront(10);
    list.insertFront(20);
    list.insertEnd(5);

    cout << "Display forward: ";
    list.displayForward();   // Output: 20 -> 10 -> 5 -> NULL

    cout << "Display backward: ";
    list.displayBackward();  // Output: 5 -> 10 -> 20 -> NULL

    return 0;
}

