#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;       // Data
    Node* next;     // Pointer to the next node
};

// Linked list class to manage nodes
class LinkedList {
private:
    Node* head;     // Pointer to the first node (head)

public:
    LinkedList() {
        head = NULL;  // Initialize the head to nullptr
    }

    // Add a node at the front of the list
    void insertFront(int value) {
        Node* newNode = new Node;  // Create a new node
        newNode->data = value;
        newNode->next = head;  // Link the new node to the existing list
        head = newNode;        // Update the head to point to the new node
    }

    // Display the list
    void display() {
        Node* current = head;
        while (current != NULL) {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList list;
    list.insertFront(10);
    list.insertFront(20);
    list.insertFront(30);
    list.insertFront(24);

    list.display();  // Output: 30 -> 20 -> 10 -> NULL

    return 0;
}

